#!/bin/bash

# Dtree bash file

python3 ./tree.py $1 $2 $3 $4

#!/bin/bash

python3 ./nnet.py $1 $2 $3
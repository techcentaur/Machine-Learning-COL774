#!/bin/bash

python3 ./_net.py $1 $2 $3 $4